import { getUncachableStripeClient } from '../server/stripeClient';

async function seedProducts() {
  console.log('Seeding Stripe products...');
  
  const stripe = await getUncachableStripeClient();

  const products = [
    {
      name: 'Starter',
      description: 'For individuals who need more power',
      metadata: { tier: 'starter' },
      price: 2500, // $25.00
    },
    {
      name: 'Pro',
      description: 'For power users and small teams',
      metadata: { tier: 'pro' },
      price: 6500, // $65.00
    },
    {
      name: 'Enterprise',
      description: 'Unlimited access for organizations',
      metadata: { tier: 'enterprise' },
      price: 19900, // $199.00
    },
  ];

  for (const productData of products) {
    try {
      const existingProducts = await stripe.products.search({
        query: `name:'${productData.name}'`,
      });

      if (existingProducts.data.length > 0) {
        console.log(`Product "${productData.name}" already exists, skipping...`);
        continue;
      }

      const product = await stripe.products.create({
        name: productData.name,
        description: productData.description,
        metadata: productData.metadata,
      });

      console.log(`Created product: ${product.name} (${product.id})`);

      const price = await stripe.prices.create({
        product: product.id,
        unit_amount: productData.price,
        currency: 'usd',
        recurring: { interval: 'month' },
      });

      console.log(`Created price: $${productData.price / 100}/month (${price.id})`);
    } catch (error: any) {
      console.error(`Error creating ${productData.name}:`, error.message);
    }
  }

  console.log('Seeding complete!');
}

seedProducts().catch(console.error);
