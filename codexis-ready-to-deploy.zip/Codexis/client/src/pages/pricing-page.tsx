import { useClerk } from "@clerk/react";
import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, X, Loader2, Crown, Zap, Rocket, Building2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { SubscriptionTier } from "@shared/schema";

interface TierInfo {
  price: number;
  name: string;
  description: string;
}

interface TierLimits {
  messages: number;
  agenic: number;
  models: string[];
}

const tierIcons: Record<SubscriptionTier, any> = {
  free: Zap,
  starter: Rocket,
  pro: Crown,
  enterprise: Building2,
};

const tierColors: Record<SubscriptionTier, string> = {
  free: "bg-muted",
  starter: "bg-blue-500/10 border-blue-500/20",
  pro: "bg-primary/10 border-primary/20",
  enterprise: "bg-amber-500/10 border-amber-500/20",
};

export function PricingPage() {
  const { openSignIn } = useClerk();
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const [selectedTier, setSelectedTier] = useState<SubscriptionTier | null>(null);

  const { data: pricingData, isLoading: pricingLoading } = useQuery<{
    tiers: Record<SubscriptionTier, TierInfo>;
    limits: Record<SubscriptionTier, TierLimits>;
  }>({
    queryKey: ["/api/pricing"],
  });

  const { data: productsData } = useQuery<{
    products: Array<{
      id: string;
      name: string;
      metadata: any;
      prices: Array<{ id: string; unit_amount: number; recurring: any }>;
    }>;
  }>({
    queryKey: ["/api/products"],
  });

  const { data: subscriptionData } = useQuery<{
    tier: SubscriptionTier;
    subscription: any;
    usage: {
      messages: number;
      agenic: number;
      messagesLimit: number;
      agenicLimit: number;
    };
    usageResetAt: string;
  }>({
    queryKey: ["/api/subscription"],
    enabled: isAuthenticated,
  });

  const checkoutMutation = useMutation({
    mutationFn: async (priceId: string) => {
      const response = await apiRequest("POST", "/api/checkout", { priceId });
      return await response.json();
    },
    onSuccess: (data) => {
      if (data.url) {
        window.location.href = data.url;
      }
    },
    onError: (error: any) => {
      toast({
        title: "Checkout failed",
        description: error.message || "Unable to start checkout",
        variant: "destructive",
      });
    },
  });

  const handleSubscribe = (tier: SubscriptionTier) => {
    if (!isAuthenticated) {
      openSignIn();
      return;
    }

    const product = productsData?.products.find(
      (p) => p.metadata?.tier === tier || p.name.toLowerCase().includes(tier)
    );
    const price = product?.prices?.[0];

    if (price) {
      setSelectedTier(tier);
      checkoutMutation.mutate(price.id);
    } else {
      toast({
        title: "No price found",
        description: "This plan is not available yet.",
        variant: "destructive",
      });
    }
  };

  if (pricingLoading || authLoading) {
    return (
      <div className="h-full flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const tiers = pricingData?.tiers || {} as Record<SubscriptionTier, TierInfo>;
  const limits = pricingData?.limits || {} as Record<SubscriptionTier, TierLimits>;
  const currentTier = subscriptionData?.tier || "free";

  const tierOrder: SubscriptionTier[] = ["free", "starter", "pro", "enterprise"];

  return (
    <div className="h-full overflow-auto">
      <div className="max-w-6xl mx-auto p-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Choose Your Plan</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Unlock the full power of multi-AI collaboration. Start free and upgrade as you grow.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {tierOrder.map((tier) => {
            const info = tiers[tier];
            const tierLimits = limits[tier];
            const Icon = tierIcons[tier];
            const isCurrentPlan = currentTier === tier;
            const isPro = tier === "pro";

            return (
              <Card
                key={tier}
                className={`relative ${tierColors[tier]} ${isPro ? "ring-2 ring-primary" : ""}`}
                data-testid={`pricing-card-${tier}`}
              >
                {isPro && (
                  <Badge className="absolute -top-3 left-1/2 -translate-x-1/2">
                    Most Popular
                  </Badge>
                )}

                <CardHeader className="text-center pb-2">
                  <div className="mx-auto mb-3 h-12 w-12 rounded-full bg-background flex items-center justify-center">
                    <Icon className="h-6 w-6" />
                  </div>
                  <CardTitle className="text-xl">{info?.name || tier}</CardTitle>
                  <CardDescription>{info?.description}</CardDescription>
                </CardHeader>

                <CardContent className="text-center">
                  <div className="mb-6">
                    <span className="text-4xl font-bold">
                      ${info?.price || 0}
                    </span>
                    {tier !== "free" && (
                      <span className="text-muted-foreground">/month</span>
                    )}
                  </div>

                  <ul className="space-y-3 text-sm text-left">
                    <li className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-500" />
                      <span>
                        {tierLimits?.messages === -1
                          ? "Unlimited messages"
                          : `${tierLimits?.messages || 0} messages/month`}
                      </span>
                    </li>
                    <li className="flex items-center gap-2">
                      {tierLimits?.agenic === 0 ? (
                        <X className="h-4 w-4 text-muted-foreground" />
                      ) : (
                        <Check className="h-4 w-4 text-green-500" />
                      )}
                      <span>
                        {tierLimits?.agenic === -1
                          ? "Unlimited Agenic collaborations"
                          : tierLimits?.agenic === 0
                          ? "No Agenic mode"
                          : `${tierLimits?.agenic} Agenic collaborations/month`}
                      </span>
                    </li>
                    <li className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-500" />
                      <span>
                        {tierLimits?.models?.length === 1
                          ? "GPT-5 model"
                          : tierLimits?.models?.length === 2
                          ? "GPT-5 + Claude"
                          : "All AI models"}
                      </span>
                    </li>
                    {tier === "enterprise" && (
                      <>
                        <li className="flex items-center gap-2">
                          <Check className="h-4 w-4 text-green-500" />
                          <span>Priority support</span>
                        </li>
                        <li className="flex items-center gap-2">
                          <Check className="h-4 w-4 text-green-500" />
                          <span>Custom integrations</span>
                        </li>
                      </>
                    )}
                  </ul>
                </CardContent>

                <CardFooter>
                  {isCurrentPlan ? (
                    <Button
                      className="w-full"
                      variant="outline"
                      disabled
                      data-testid={`button-current-plan-${tier}`}
                    >
                      Current Plan
                    </Button>
                  ) : tier === "free" ? (
                    <Button
                      className="w-full"
                      variant="outline"
                      disabled
                      data-testid={`button-free-tier`}
                    >
                      Free Forever
                    </Button>
                  ) : (
                    <Button
                      className="w-full"
                      variant={isPro ? "default" : "outline"}
                      onClick={() => handleSubscribe(tier)}
                      disabled={checkoutMutation.isPending && selectedTier === tier}
                      data-testid={`button-subscribe-${tier}`}
                    >
                      {checkoutMutation.isPending && selectedTier === tier ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : null}
                      {isAuthenticated ? "Subscribe" : "Sign up"}
                    </Button>
                  )}
                </CardFooter>
              </Card>
            );
          })}
        </div>

        {isAuthenticated && subscriptionData && (
          <Card className="max-w-xl mx-auto">
            <CardHeader>
              <CardTitle>Your Usage</CardTitle>
              <CardDescription>Current billing period</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>Messages used</span>
                  <span className="font-medium">
                    {subscriptionData.usage?.messages || 0}
                    {subscriptionData.usage?.messagesLimit !== -1 &&
                      ` / ${subscriptionData.usage?.messagesLimit}`}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Agenic collaborations</span>
                  <span className="font-medium">
                    {subscriptionData.usage?.agenic || 0}
                    {subscriptionData.usage?.agenicLimit !== -1 &&
                      ` / ${subscriptionData.usage?.agenicLimit}`}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="mt-12 text-center">
          <h3 className="text-xl font-semibold mb-4">Frequently Asked Questions</h3>
          <div className="max-w-2xl mx-auto text-left space-y-4">
            <div>
              <h4 className="font-medium">Can I cancel anytime?</h4>
              <p className="text-sm text-muted-foreground">
                Yes, you can cancel your subscription at any time. You'll continue to have access until the end of your billing period.
              </p>
            </div>
            <div>
              <h4 className="font-medium">What happens if I exceed my limits?</h4>
              <p className="text-sm text-muted-foreground">
                You'll be prompted to upgrade your plan. Your work is never lost.
              </p>
            </div>
            <div>
              <h4 className="font-medium">Do unused messages roll over?</h4>
              <p className="text-sm text-muted-foreground">
                Usage resets at the beginning of each billing cycle. Unused messages don't roll over.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
